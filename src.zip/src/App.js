import React from "react";
import AvatarMaker from "./avatars/avatarCreator";

function App() {
  return <AvatarMaker />;
}

export default App;
