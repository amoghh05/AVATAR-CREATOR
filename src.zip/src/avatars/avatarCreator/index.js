import React from "react";
import AvatarLayout from "./AvatarLayout";

function AvatarMaker() {
  return (
    <>
      <AvatarLayout />
    </>
  );
}

export default AvatarMaker;
