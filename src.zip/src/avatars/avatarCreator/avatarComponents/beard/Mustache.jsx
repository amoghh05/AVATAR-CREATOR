import React from "react";

function Mustache() {
  return (
    <path
      className="hairMediumShade"
      d="m 240.81387,300.90502 h 33.80601 a 25.985982,19.174446 0 0 1 25.95801,19.17442 v 0 h -85.75 v 0 a 25.985982,19.174446 0 0 1 25.98598,-19.17442 z"
      id="path183"
    />
  );
}

export default Mustache;
