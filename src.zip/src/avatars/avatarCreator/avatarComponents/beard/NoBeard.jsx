import React from "react";

export default function NoBeard() {
  return <></>;
}
