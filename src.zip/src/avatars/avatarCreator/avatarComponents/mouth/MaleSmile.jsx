import React from "react";

function MaleSmile() {
  return (
    <path
      d="m 234.34837,321.69329 a 2.0487761,2.0487761 0 0 0 -2.0401,2.21373 c 1.11121,13.69901 12.4142,26.39969 26.19137,26.39969 v 0 c 13.77714,0 25.08013,-12.70068 26.19133,-26.39969 a 2.040095,2.040095 0 0 0 -2.0314,-2.21373 z"
      id="path1792"
      style={{ fill: "#ffffff", strokeWidth: "0.868126" }}
    />
  );
}

export default MaleSmile;
