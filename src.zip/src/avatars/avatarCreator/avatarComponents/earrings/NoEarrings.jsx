import React from "react";

function NoEarrings() {
  return <></>;
}

export default NoEarrings;
